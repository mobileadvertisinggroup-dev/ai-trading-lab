# D46 — RISK_POLICY v2 adjudication + §16 assessment

**Change**: drawdown reference all-time peak → trailing 90-day peak
(RiskLimits.drawdown_window_days=90). Commit 5f83b66; exact diff in
exact_diff_D46.patch; adjudication text in BUILD_STATE D46.

**Why v1 was absorbing** (absorbing_state_evidence.json, from the
preserved v1 run): pause blocks new entries; a flat account cannot
recover equity; drawdown from an all-time peak therefore never falls
below the limit again. Observed: frozen 9,220/9,848 rounds; final equity
a permanent 0.4% below the release level; 337 labels, 0 validation labels
— the experiment was unexecutable.

**Why v2 releases** (v2_release_evidence.json + unit test): the reference
peak ages out of the 90-day window; crash response is unchanged (a ≥25%
fall inside any 90-day window pauses immediately); the pause horizon is
bounded; risk can never be increased by the change.

**§16 assessment**: the change PRECEDED the constitutional lock, all
model training, all features, and the shakedown; RISK_POLICY numeric
limits were explicitly draft until the lock (D15). Required invalidation
= discard-and-regenerate everything derived from the v1 run: PERFORMED —
the complete Arm A run, labels, features, learnability, training, and
shakedown were all produced ONLY from the v2 run; the v1 ledgers were
never consumed downstream and are preserved as v1policy_* for audit. No
official result, lock, or shakedown existed before the change, so no
post-hoc invalidation debt remains.
