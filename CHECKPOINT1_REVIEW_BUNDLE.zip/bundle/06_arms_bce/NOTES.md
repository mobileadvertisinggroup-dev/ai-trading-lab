# Arms B/C/E notes
- Frozen features: F01-F28 (features-v1-draft; canonical order in
  lab/features/build.py FEATURE_NAMES); feature parquet sha in
  features_manifest.json.
- Hyperparameters: _LGB_DRAFT in pipelines_training_code.py (100/4/0.05/
  0.8/0.8) — DRAFT, deliberately unsearched. Model-selection attempts:
  NONE (no search was run; the learnability null is reported instead of
  being tuned away). Thresholds: B=0.5 draft; E bucket mapping =
  training-prediction quartiles (draft; spec-§3 utility mapping is a
  Checkpoint-2 freeze item — the utility calculation therefore does not
  exist yet and is NOT claimed).
- Purge/embargo evidence: validate_split refuses any training example
  whose info interval reaches the validation boundary (leak battery);
  split counts train 2,089 / validation 750 / purged 1 (features_manifest).
- Training/validation metrics: model_manifest.json (B AUC .533, accept
  1.1%, accepted mean net_r -.334; C IC .020; E bucket means
  non-monotonic).
