# Arm F adjudication pack — SD-RLOBS and the CEM deviation

## Exact 10-dim training observation schema (rl_environment.py `_obs`)
0 unrealized R; 1 time-in-trade fraction; 2 MFE in R; 3 MAE in R;
4 ATR-relative vol now/entry; 5 momentum deterioration; 6 distance to
stop in R; 7 distance to target in R; 8 remaining size fraction;
9 portfolio exposure fraction.

## Exact observation supplied at orchestrator inference
`Competition._rl_management` builds `{"unrealized_r": ..., "bars_held": ...}`
only. The adapter (orchestrator_inference_adapter.py) maps: dim0 =
unrealized_r; dim1 = bars_held/42; dims 2-9 = 0.0.

## How the mismatch was handled
The incorrect observation was **zero-PADDED and accepted** by the adapter
— not rejected, not transformed further, and NOT silently: the mismatch
was pre-registered in the adapter's docstring and in the defect record
(SD-RLOBS) BEFORE shakedown run 2 executed.

## Scope across F / G / G-shadow
- Arm F: management decisions only (entries are frozen Arm-A logic).
- Arm G: management decisions only (the G entry path uses B/C/E/D, not F).
- G-shadow: UNAFFECTED — conventional frozen management by construction;
  its entry identity with G was verified and passed.
- Official Arm A ledgers, labels, features, learnability: UNAFFECTED
  (Arm F plays no role in them).

## Why run 2 was described as "clean"
"Clean" referred to OPERATIONAL execution: 1,080/1,080 valid rounds, all
arms deciding, no exceptions, identity checks passing. It was NOT a claim
that Arm F/G management behaved as trained — the defect record filed in
the same run states the opposite. The reviewer's framing is accepted:
the shakedown does NOT establish Arm F / G-RL correctness. That is
precisely why SD-RLOBS is OPEN and blocking in the Checkpoint-1 report.

## Material-change / retraining assessment
Fixing SD-RLOBS extends the orchestrator observation to the full 10-dim
schema → an interface change consumed by the frozen policy → Arm F
retraining REQUIRED after the fix (policy trained under the 10-dim env is
then evaluated under matching inference). Arms A-E unaffected. A new
shakedown is required after the fix per §16/§20. None of this has been
started: the defective state is preserved as instructed.

## CEM instead of Stable-Baselines3 — DEVIATION FOR ADJUDICATION
Spec §7 line: "Use a stable, documented algorithm from Stable-Baselines3
unless discovery justifies a better documented standard." Spec §27 lists
SB3 in the default stack.
Discovery evidence relied on (recorded here honestly):
1. requirements.txt pins NO torch/SB3 (the project's pinned, reproducible
   environment was fixed before training; adding torch (~800 MB, own BLAS
   threading) mid-assignment would have changed the pinned environment);
2. determinism: the constitutional posture demands bit-reproducible
   official runs; CEM over a 66-parameter linear softmax with all
   randomness derived from the official seed is bit-reproducible on CPU,
   which SB3+torch does not guarantee across builds without additional
   pinning;
3. compute: 4 CPU cores, profiled budget 3h for 10 seeds — met (1,206s).
ASSESSMENT: CEM (cross-entropy method) is a documented standard method,
but whether this satisfies the spec's "better documented standard" bar is
EXPLICITLY submitted to review rather than self-adjudicated. If review
directs SB3, the natural sequencing is: fix SD-RLOBS → adopt SB3
(pinned) → retrain 10 seeds → new shakedown; costs and determinism
mitigations to be proposed then.
