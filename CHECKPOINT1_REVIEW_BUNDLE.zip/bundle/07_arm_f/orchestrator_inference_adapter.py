class FrozenRLPolicy:
    """Adapter from the orchestrator's management-observation dict to the
    trained 10-dim policy. KNOWN INTEGRATION DEFECT (recorded for the
    Checkpoint-1 inventory): the orchestrator supplies only
    {unrealized_r, bars_held}, a strict subset of the 10-dim training
    observation; the remaining dims are fed as 0. The shakedown exists to
    surface exactly this class of mismatch."""
    ACTIONS = ("hold", "reduce_25", "reduce_50", "close", "tighten_stop",
               "move_stop_breakeven")

    def __init__(self, model_dir):
        z = np.load(os.path.join(model_dir, "arm_f_policy.npz"))
        self.policy = LinearPolicy(z["theta"])
        self.version = f"F-cem-seed{int(z['seed'])}-frozen"

    def action(self, obs: dict) -> str:
        v = np.zeros(10)
        v[0] = obs.get("unrealized_r", 0.0)
        v[1] = min(1.0, obs.get("bars_held", 0) / P.MAX_HOLD_BARS_4H)
        return self.ACTIONS[self.policy.act(v)]
