# Reproducing the verification

1. Clone https://github.com/mobileadvertisinggroup-dev/ai-trading-lab at
   the HEAD commit in HEAD_COMMIT.txt (plus the bundle-doc commit that
   follows it — see GIT_STATUS.txt).
2. `pip install -r requirements.txt` (exact pins).
3. `python -m pytest tests/ -q` → must match TESTS_RERUN.txt (136 passed).
4. Verify the constitutional lock: recompute sha256 of every path in
   data/manifests/integrity_manifest.json and compare (see
   10_constitutional_lock/lock_verification.json — ALL MATCH at packaging).
5. Verify the external root hash: recompute per
   data/manifests/checkpoint1_root_hash.json (canonical JSON of the 13
   component hashes) → must equal
   80c7c5b578ce168a4a391812e560aa451a3f2dc20af8993d950158d11dcabcaf.
6. Full ledgers/models/shakedown artifacts live in the repository under
   data/ledgers, data/models, data/shakedown, data/shakedown_run1 with
   sha256 in their manifests (bundle carries samples + hashes only).
7. Reproducing official runs end-to-end additionally requires downloading
   the published raw-v1 release (hash-verify per SHA256SUMS + lake
   manifest) — see lab/tools/verify_lake.py, run_arm_a.py; no raw market
   data is included in this bundle by instruction.
