# D47 — forced_delist_close conformance fix

**Frozen rule** (EXPERIMENT_PROTOCOL §2, Phase-1 frozen, UNCHANGED):
"Open position, symbol delisted / trading halted permanently: position is
closed at the last traded 15m close with double slippage per §5, logged
forced_delist_close." The runner lacked the mid-run case — a conformance
GAP closed, not a protocol change.

**Failure evidence**: under v2 policy the account stayed active 4.5y; a
delisted open position re-queued a time-exit every boundary, and every
queued exit emitted exit_deferred every 15m bar → quadratic event growth;
the run was OOM-killed at ~13.9 GB anon RSS (kernel oom-kill record in
session logs). No artifacts were produced by that run — nothing to
invalidate from it.

**Fix** (commit 74fe9e6, exact_diff_D47.patch): Engine.force_close
(single position, 2x slip) + runner detection via the frozen §4
TRADABLE_LOOKBACK (2 days of bar ABSENCE — point-in-time, no lookahead).
Regression test: tests_arm_a.py::test_forced_delist_close_and_no_deferral_flood.

**Affected candidates/trades/results + regeneration record**: the only
completed pre-fix run was the v1-policy run (superseded by D46
independently). The OFFICIAL ledgers (data/ledgers/, hashes in
ledger_manifest_arm_a.json) were generated in a single run AFTER both
D46 and D47; they contain 4 forced_delist_close events and 26,023
candidates. Nothing downstream ever consumed pre-fix outputs.
