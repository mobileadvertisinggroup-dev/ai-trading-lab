REVIEW DELTA PACKAGE - PHASE 6 (responds to the independent
review verdict, all eight sections). Start with TESTS_RERUN.txt,
then reviews/REVIEW_VERDICT_PHASE6.md (the verdict, verbatim),
then item-by-item:
 SS1 G03: fixtures/golden/G03_..._v2.json + superseded/v1 + lineage
 SS2/SS3: approvals recorded in BUILD_STATE (D25)
 SS4 PC-1: PROPOSED_CLARIFICATION_PC1.md (awaiting user approval)
 SS5: .github/workflows/ingest.yml (pins, transaction order,
      evidence, verified destruction) + probe timing in ingest.py
 SS6: data/manifests/exclusion_registry_v1.json + ingest.py
 SS7: lab/data/authz.py, lab/data/unseal.py, access.py,
      tests/test_authz_negative.py
 SS8: this package; STOP honored.
Source commit: 1e191dd0b5388268e15adbc45d8eb5acc2e9bbf7
No secrets, identities, holdout rows, market data, or credentials.
